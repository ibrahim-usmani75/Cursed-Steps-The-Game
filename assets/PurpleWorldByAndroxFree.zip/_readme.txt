Thank you for purchasing this pack!
I truly appreciate your support and hope you enjoy using it. If you encounter any issues or would like something customized, feel free to reach out to me via:

Instagram: @undeprixelarted
Email: anders0nfern4ndez@gmail.com
Thanks again! 😊
___________________________________________________________________________________________
Important:

Each asset is individually cropped and organized as follows:

Buildings:
Farm
House
Pumpkin
Smithy

Nature:
Bushes
Plants & others
Rocks
Trees

Objects:
Barrel & bucket
Boxes
Chests
Others
Signs

Terrain tiles:
Bridge & stairs
Fences
Ground 
Slabs
Walls 
Water & bushes

The assets are not trimmed; they are aligned to a 16x16 grid.
Numbers on some assets indicate their relative size. For example: bush1 < bush2 < bush3.
